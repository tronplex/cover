import json
import requests
import textwrap
from tabulate import tabulate
from datetime import datetime, timedelta
import boto3
import os
import email
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# MAIN FUNCTION
def lambda_handler(event, context):

    kev_url = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'
    
    # PARAMETERS
    email_recipient = os.environ.get('EMAIL_RECIPIENT')
    email_sender = os.environ.get('EMAIL_SENDER')
    
    # USER DEFINED SOFTWARE LIST
    software_list = "/tmp/software.txt"
    # FILTER BY DATE (CURRENT-LAST 30 DAYS)
    current_date = datetime.now()
    cutoff_date = current_date -timedelta(days=30)
    today = datetime.now().strftime("%Y-%m-%d")
    # NAMING REPORTS TO INCLUDE DATES
    json_filename = f"/tmp/COVERreport_{today}.json"
    text_filename = f"/tmp/COVERreport_{today}.txt"

    # LAMBDA ENVIRONMENTAL VARIABLE FOR S3
    s3_bucket = event.get('bucket', os.environ.get('S3_BUCKET'))
    if not s3_bucket:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Error: S3 not specified or not available in event or environment variables'})
        }
    
    s3_client = boto3.client('s3')
    ses_client = boto3.client('ses')

    # RETRIEVE SOFTWARE LIST FROM S3
    try:
        s3_client.download_file(s3_bucket, 'software.txt', software_list)
    except s3_client.exceptions.NoSuchKey:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error: File 'software.txt' not found in S3 {s3_bucket}"})
        }
    except Exception as error:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error downloading file from S3: {str(error)}"})
        }

    # READ SOFTWARE LIST
    try:
        with open(software_list, "r") as software:
            vendors = [vendor.strip() for vendor in software if vendor.strip()]
    except Exception as error:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error reading file: {str(error)}"})
        }
    # READ CISA KEV
    try:
        response = requests.get(kev_url, timeout=20)
        response.raise_for_status()
        kev_data = response.json()
    except requests.exceptions.RequestException as error:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error retrieving KEV Vulnerability data: {str(error)}"})
        }
    # CHANGE VENDOR CASE & FIND VULNS THAT MATCH VENDOR LIST
    vendors_lower = [vendor.lower() for vendor in vendors]
    cve_hits = [
        vuln for vuln in kev_data["vulnerabilities"]
        if vuln.get("vendorProject", "").lower() in vendors_lower
    ]
    # FILTER VULNS BY DATE
    latest_cves = []
    for cve in cve_hits:
        if "dateAdded" not in cve:
            continue
        try:
            date_added = datetime.strptime(cve["dateAdded"], "%Y-%m-%d")
        except ValueError:
            continue
        if date_added >= cutoff_date:
            latest_cves.append(cve)
    # CREATE JSON FILE, WRITE, AND PUBLISH TO S3
    try:
        with open(json_filename, 'w') as file:
            json.dump(latest_cves, file, indent = 4)
        s3_client.upload_file(json_filename, s3_bucket, f"COVERreport_{today}.json")
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error saving JSON report: {str(e)}"})
        }

    # CREATE TXT REPORT, WRITE, AND PUBLISH TO S3
    try:
        with open(text_filename, 'w') as f:
            f.write("*** CISA OBSERVED VULNERABILITY EXPLOITATION REPORT ***\n")
            f.write(f"Report Date: {current_date.strftime('%Y-%m-%d')}\n")
            f.write(f"Entries newer than: {cutoff_date.strftime('%Y-%m-%d')} (30 Days)\n")
            f.write(f"Total Entries: {len(latest_cves)}\n")
            f.write("********************************\n\n")
            if latest_cves:
                table_data = [
                    [
                        i,
                        cve.get('cveID', 'n/a'),
                        cve.get('dateAdded', 'n/a'),
                        cve.get('vendorProject', 'n/a'),
                        cve.get('product', 'n/a'),
                        textwrap.fill(cve.get('shortDescription', 'n/a'), width=30, replace_whitespace=False)
                    ]
                    for i, cve in enumerate(latest_cves, 1)
                ]
                headers = ["Entry #", "CVE", "Date Added", "Vendor", "Product", "Descritpion"]
                f.write(tabulate(table_data, headers=headers, tablefmt="grid", maxcolwidths=[10, 15, 12, 25]))
            else:
                f.write("No new entries found within the last 30 days.\n")
        s3_client.upload_file(text_filename, s3_bucket, f"COVERreport_{today}.txt")

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error saving text report: {str(e)}"})
        }
    
    try:

        # Redefine today here to match any potential date drift
        today = datetime.now().strftime("%Y-%m-%d")
    
        msg = MIMEMultipart()
        msg['Subject'] = f"COVER Vulnerability Reports - {today}"
        msg['From'] = email_sender
        msg['To'] = email_recipient

        body = (
            f"CISA Observed Vulnerability Exploitation Reports Generated on {today}\n\n"
            f"Total CVEs: {len(latest_cves)}\n"
            f"Attached: JSON and Text reports"
        )

        msg.attach(MIMEText(body, 'plain'))

        # JSON attachment
        json_obj = s3_client.get_object(Bucket=s3_bucket, Key=f"COVERreport_{today}.json")
        json_data = json_obj['Body'].read().decode('utf-8')

        json_part = MIMEBase('application', 'json')
        json_part.set_payload(json_data)
        encoders.encode_base64(json_part)
        json_part.add_header('Content-Disposition', f'attachment; filename=COVERreport_{today}.json')
        msg.attach(json_part)
    
        # TXT attachment
        txt_obj = s3_client.get_object(Bucket=s3_bucket, Key=f"COVERreport_{today}.txt")
        txt_data = txt_obj['Body'].read().decode('utf-8')

        txt_part = MIMEBase('text', 'plain')
        txt_part.set_payload(txt_data)
        encoders.encode_base64(txt_part)
        txt_part.add_header('Content-Disposition', f'attachment; filename=COVERreport_{today}.txt')
        msg.attach(txt_part)

        ses_client.send_raw_email(
            Source=email_sender,
            Destinations=[email_recipient],
            RawMessage={'Data': msg.as_string()} 
        )
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f"Error publishing to SES: {str(e)}"})
        }

# Move the success return outside the try-except
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Success',
            'json_report': f"s3://{s3_bucket}/COVERreport_{today}.json",
            'text_report': f"s3://{s3_bucket}/COVERreport_{today}.txt",
            'total_entries': len(latest_cves)
        })
}
